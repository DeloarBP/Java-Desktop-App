
package start_19_04_18;

import java.net.URL;
import java.util.Observable;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author mddel
 */
public class FXMLDocumentController implements Initializable {
    
    
    @FXML
    private ListView<String> text_List;
    
    ObservableList<String> list = FXCollections.observableArrayList();
    @FXML
    private TextField textinput;
    
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

//        text_List.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);//select korarr jonno ai ta 
    }    

    @FXML
    private void addButton(ActionEvent event) {
        
        String add = textinput.getText();
        
        if(add.equals(""))return;
        list.add(add);
        
        text_List.setItems(list);
        
        textinput.clear();
    }

     ObservableList<String> selectedItem = FXCollections.observableArrayList();
     
     
    @FXML
    private void deleteButtton(ActionEvent event) {

        list.removeAll(selectedItem);
    
    }

   
    
    @FXML
    private void mouseAct(MouseEvent event) {

    selectedItem = text_List.getSelectionModel().getSelectedItems();
        
    }
    
}
